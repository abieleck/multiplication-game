package com.example.android.multiplicationgame.view.timer

interface TimerAnimatorListener {
    fun onAnimationFrame(currentPlayTime: Long)
}