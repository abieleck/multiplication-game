package com.example.android.multiplicationgame.view.timer

interface LaunchTimerListener {

    fun onBallLaunch()
}